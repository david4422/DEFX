/*
  ==============================================================================

    DelayGUI.cpp
    Created: 28 Apr 2022 1:41:47pm
    Author:  david

  ==============================================================================
*/

#include <JuceHeader.h>
#include "DelayGUI.h"

//==============================================================================
DelayGUI::DelayGUI(DEFXAudioProcessor& p) : audioProcessor(p),
// Sliders Presentation and Units
feedbackSlider(*audioProcessor.apvts.getParameter("DELAY_FEEDBACK"), "db"),
rateSlider(*audioProcessor.apvts.getParameter("DELAY_RATE"), "ms"),
mixSlider(*audioProcessor.apvts.getParameter("DELAY_MIX"), "%"),
// Sliders State Attachments
feedbackSliderAttachment(audioProcessor.apvts, "DELAY_FEEDBACK", feedbackSlider),
rateSliderAttachment(audioProcessor.apvts, "DELAY_RATE", rateSlider),
mixSliderAttachment(audioProcessor.apvts, "DELAY_MIX", mixSlider)
{
    // Min Max Labels
   setSlidersMinMaxLables();

    // Gets all the sliders and make them visible
    setGUIVisible();

    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    // Set the Window Size
    setSize(600, 400);

}

DelayGUI::~DelayGUI()
{
}

void DelayGUI::paint (juce::Graphics& g)
{
    g.setColour(juce::Colours::grey);
    g.drawRect(getLocalBounds(), 1);   // draw an outline around the component

    g.setColour(juce::Colours::black);
    float fontSize = 50.f;
    g.setFont(fontSize);
    g.drawText("Feedback   |   Rate   |   Mix", 10, 10, getWidth(), fontSize, juce::Justification::left, true);

}

void DelayGUI::resized()
{
    drawGUI();
}

std::vector<juce::Component*> DelayGUI::getComponents()
{
    return
    {
        &feedbackSlider,
        &rateSlider,
        &mixSlider
    };
}

void DelayGUI::setSlidersMinMaxLables()
{
    feedbackSlider.labels.add({ 0.f,"-6db" });
    feedbackSlider.labels.add({ 1.f,"0db" });

    rateSlider.labels.add({ 0.f,"0.48ms" });
    rateSlider.labels.add({ 1.f,"1000ms" });

    mixSlider.labels.add({ 0.f,"0%" });
    mixSlider.labels.add({ 1.f,"100%" });
}

void DelayGUI::setGUIVisible()
{
    // Gets all the sliders and make them visible
    for (auto* component : getComponents())
    {
        addAndMakeVisible(component);
    }
}

void DelayGUI::drawGUI()
{
    juce::Rectangle<int> feedbackSliderRect(getWidth() / 6 * 1 - 87, getHeight() / 4 * 2 - 87, 175, 175);
    feedbackSlider.setBounds(feedbackSliderRect);

    juce::Rectangle<int> rateliderRect(getWidth() / 6 * 3 - 87, getHeight() / 4 * 2 - 87, 175, 175);
    rateSlider.setBounds(rateliderRect);

    juce::Rectangle<int>mixSliderRect(getWidth() / 6 * 5 - 87, getHeight() / 4 * 2 - 87, 175, 175);
    mixSlider.setBounds(mixSliderRect);
}
