/*
  ==============================================================================

    Pedal.cpp
    Created: 17 Apr 2022 4:19:31pm
    Author:  david

  ==============================================================================
*/

#include <JuceHeader.h>
#include "Pedal.h"

//==============================================================================
Pedal::Pedal()
{
    title = "FX";
    setGUIVisible();
}

Pedal::Pedal(juce::String title)
{
    this->title = title;
    setGUIVisible();
}

Pedal::~Pedal()
{
}

void Pedal::paint (juce::Graphics& g)
{
    g.setColour(juce::Colours::black);
    g.drawRect(getLocalBounds(), 1);   // draw an outline around the component

    g.setColour (juce::Colours::black);
    float fontSize = 25.0f;
    g.setFont (fontSize);
    g.drawText (title, 0,10,getWidth(), fontSize,juce::Justification::centred, true);   // draw some placeholder text
}

void Pedal::resized()
{
    drawGUI();
}

std::vector<juce::Component*> Pedal::getComponents()
{
    return
    {
        &powerButton,
        &displayButton
    };
}

void Pedal::setGUIVisible()
{
    // Gets all the GUI component and make them visible
    for (auto* component : getComponents())
    {
        addAndMakeVisible(component);
    }
}

void Pedal::enableDisableGUI()
{
}

void Pedal::drawGUI()
{
    // The pedal size 200x200
    // Power button
    juce::Rectangle<int> powerButtonRect(getWidth() / 4 * 1 - 25, getHeight() / 4 * 2 - 25, 50, 50);
    powerButton.setBounds(powerButtonRect);

    // display button
    juce::Rectangle<int> displayButtonRect(getWidth() / 4 * 3 - 25, getHeight() / 4 * 2 - 25, 50, 50);
    displayButton.setBounds(displayButtonRect);
}

