/*
  ==============================================================================

    Reverb.h
    Created: 28 Apr 2022 1:40:15pm
    Author:  david

  ==============================================================================
*/

#pragma once
class Reverb
{
public:
	Reverb();
	~Reverb();

private:

};

Reverb::Reverb()
{
}

Reverb::~Reverb()
{
}