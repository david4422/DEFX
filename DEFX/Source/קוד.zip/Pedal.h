/*
  ==============================================================================

    Pedal.h
    Created: 17 Apr 2022 4:19:31pm
    Author:  david

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "GUIComponents.h"

//==============================================================================
/*
*/
class Pedal  : public juce::Component
{
public:
    Pedal();
    Pedal(juce::String title);
    ~Pedal() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    // Title
    juce::String title;

    PowerButton powerButton;
    GButton displayButton;

    //Getting the Components
    std::vector<juce::Component*> getComponents();

    // For constructor
    void setGUIVisible();
    //void setGUIAttachment();
    void enableDisableGUI();

    // For resize
    void drawGUI();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Pedal)
};
