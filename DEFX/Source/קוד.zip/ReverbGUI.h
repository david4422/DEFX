/*
  ==============================================================================

    ReverbGUI.h
    Created: 28 Apr 2022 1:41:11pm
    Author:  david

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>

//==============================================================================
/*
*/
class ReverbGUI  : public juce::Component
{
public:
    ReverbGUI();
    ~ReverbGUI() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ReverbGUI)
};
