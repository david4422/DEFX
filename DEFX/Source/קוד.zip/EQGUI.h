/*
  ==============================================================================

    EQGUI.h
    Created: 17 Apr 2022 4:17:51pm
    Author:  david

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "GUIComponents.h"

//==============================================================================
/*
*/
class EQGUI  : public juce::Component
{
public:
    EQGUI(DEFXAudioProcessor& p);
    ~EQGUI() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:

    DEFXAudioProcessor& audioProcessor;

    // The Sliders
    RotarySliderWithLabels lowCutFreqSlider;
    RotarySliderWithLabels lowCutSlopeSlider;
    RotarySliderWithLabels peakFreqSlider;
    RotarySliderWithLabels peakGainSlider;
    RotarySliderWithLabels peakQualitySlider;
    RotarySliderWithLabels highCutFreqSlider;
    RotarySliderWithLabels highCutSlopeSlider;

    // Buttons
    PowerButton lowcutBypassedButton;
    PowerButton peakBypassedButton;
    PowerButton highcutBypassedButton;

    // Attachments
    using APVTS = juce::AudioProcessorValueTreeState;
    using Attachment = APVTS::SliderAttachment;

    Attachment lowCutFreqAttachment;
    Attachment lowCutSlopeAttachment;
    Attachment peakFreqAttachment;
    Attachment peakGainAttachment;
    Attachment peakQualityAttachment;
    Attachment highCutFreqAttachment;
    Attachment highCutSlopeAttachment;

    // Button attachment
    using ButtonAttachment = APVTS::ButtonAttachment;
    ButtonAttachment lowcutBypassedButtonAttachment;
    ButtonAttachment peakBypassedButtonAttachment;
    ButtonAttachment highcutBypassedButtonAttachment;

    //Getting the Components
    std::vector<juce::Component*> getComponents();

    // For constructor
    void setSlidersMinMaxLables();
    void setGUIVisible();
    void enableDisableGUI();

    // For resize
    void drawGUI();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (EQGUI)
};
