/*
  ==============================================================================

    DelayGUI.h
    Created: 28 Apr 2022 1:41:47pm
    Author:  david

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "GUIComponents.h"

//==============================================================================
/*
*/
class DelayGUI  : public juce::Component
{
public:
    DelayGUI(DEFXAudioProcessor& p);
    ~DelayGUI() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    // Audio Processor
    DEFXAudioProcessor& audioProcessor;

    // Sliders
    RotarySliderWithLabels feedbackSlider;
    RotarySliderWithLabels rateSlider;
    RotarySliderWithLabels mixSlider;

    // Attachments
    using APVTS = juce::AudioProcessorValueTreeState;
    using Attachment = APVTS::SliderAttachment;

    Attachment feedbackSliderAttachment;
    Attachment rateSliderAttachment;
    Attachment mixSliderAttachment;

    //Getting the Components
    std::vector<juce::Component*> getComponents();

    // For constructor
    void setSlidersMinMaxLables();
    void setGUIVisible();

    // For resize
    void drawGUI();


    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DelayGUI)

};
