/*
  ==============================================================================

    PeadalBoard.h
    Created: 17 Apr 2022 4:20:06pm
    Author:  david

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "Pedal.h"

//==============================================================================
/*
*/
class PeadalBoard  : public juce::Component
{
public:
    PeadalBoard();
    ~PeadalBoard() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:

    // Pedals
    Pedal eqPedal{ "EQ" };
    Pedal delayPedal{ "Delay" };
    Pedal reverbPedal{ "Reverb" };
    
    //Getting the Components
    std::vector<juce::Component*> getComponents();

    // For constructor
    void setGUIVisible();

    // For resize
    void drawGUI();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PeadalBoard)
};
