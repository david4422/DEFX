/*
  ==============================================================================

    EQGUI.cpp
    Created: 17 Apr 2022 4:17:51pm
    Author:  david

  ==============================================================================
*/

#include <JuceHeader.h>
#include "EQGUI.h"

//==============================================================================
EQGUI::EQGUI(DEFXAudioProcessor& p) : audioProcessor(p), 
// Sliders Presentation and Units
lowCutFreqSlider(*audioProcessor.apvts.getParameter("EQ_LOW_CUT_FREQ"), "Hz"),
lowCutSlopeSlider(*audioProcessor.apvts.getParameter("EQ_LOW_CUT_SLOPE"), "dB/Oct"),
peakFreqSlider(*audioProcessor.apvts.getParameter("EQ_PEAK_FREQ"), "Hz"),
peakGainSlider(*audioProcessor.apvts.getParameter("EQ_PEAK_GAIN"), "dB"),
peakQualitySlider(*audioProcessor.apvts.getParameter("EQ_PEAK_QUALITY"), ""),
highCutFreqSlider(*audioProcessor.apvts.getParameter("EQ_HIGH_CUT_FREQ"), "Hz"),
highCutSlopeSlider(*audioProcessor.apvts.getParameter("EQ_HIGH_CUT_SLOPE"), "dB/Oct"),
// Sliders State Attachments
lowCutFreqAttachment(audioProcessor.apvts, "EQ_LOW_CUT_FREQ", lowCutFreqSlider),
lowCutSlopeAttachment(audioProcessor.apvts, "EQ_LOW_CUT_SLOPE", lowCutSlopeSlider),
peakFreqAttachment(audioProcessor.apvts, "EQ_PEAK_FREQ", peakFreqSlider),
peakGainAttachment(audioProcessor.apvts, "EQ_PEAK_GAIN", peakGainSlider),
peakQualityAttachment(audioProcessor.apvts, "EQ_PEAK_QUALITY", peakQualitySlider),
highCutFreqAttachment(audioProcessor.apvts, "EQ_HIGH_CUT_FREQ", highCutFreqSlider),
highCutSlopeAttachment(audioProcessor.apvts, "EQ_HIGH_CUT_SLOPE", highCutSlopeSlider),
// Toggle buttons state attachment
lowcutBypassedButtonAttachment(audioProcessor.apvts, "EQ_LOW_CUT_BYPASSED", lowcutBypassedButton),
peakBypassedButtonAttachment(audioProcessor.apvts, "EQ_PEAK_BYPASSED", peakBypassedButton),
highcutBypassedButtonAttachment(audioProcessor.apvts, "EQ_HIGH_CUT_BYPASSED", highcutBypassedButton)
{
    // Min Max Labels
    setSlidersMinMaxLables();

    // Gets all the sliders and make them visible
    setGUIVisible();

    //
    enableDisableGUI();

    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    // Set the Window Size
    setSize(600, 400);
}

EQGUI::~EQGUI()
{
}

void EQGUI::paint (juce::Graphics& g)
{
    g.setColour (juce::Colours::grey);
    g.drawRect (getLocalBounds(), 1);   // draw an outline around the component
}

void EQGUI::resized()
{
    drawGUI();
}

std::vector<juce::Component*> EQGUI::getComponents()
{
    return
    {  
        // Low Cut
        &lowCutFreqSlider,
        &lowCutSlopeSlider,
        &lowcutBypassedButton,

        // Peak
        &peakFreqSlider,
        &peakGainSlider,
        &peakQualitySlider,
        &peakBypassedButton,

        // High Cut
        &highCutFreqSlider,
        &highCutSlopeSlider,
        &highcutBypassedButton
    };
}

void EQGUI::setSlidersMinMaxLables()
{
    // Min Max Labels
    lowCutFreqSlider.labels.add({ 0.f,"20Hz" });
    lowCutFreqSlider.labels.add({ 1.f,"20kHz" });
    lowCutSlopeSlider.labels.add({ 0.f,"12dB/Oct" });
    lowCutSlopeSlider.labels.add({ 1.f,"48dB/Oct" });

    peakFreqSlider.labels.add({ 0.f,"20Hz" });
    peakFreqSlider.labels.add({ 1.f,"20kHz" });
    peakGainSlider.labels.add({ 0.f,"-24dB" });
    peakGainSlider.labels.add({ 1.f,"24dB" });
    peakQualitySlider.labels.add({ 0.f,"0.1" });
    peakQualitySlider.labels.add({ 1.f,"10.0" });

    highCutFreqSlider.labels.add({ 0.f,"20Hz" });
    highCutFreqSlider.labels.add({ 1.f,"20kHz" });
    highCutSlopeSlider.labels.add({ 0.f,"12dB/Oct" });
    highCutSlopeSlider.labels.add({ 1.f,"48dB/Oct" });
}

void EQGUI::setGUIVisible()
{
    // Gets all the sliders and make them visible
    for (auto* component : getComponents())
    {
        addAndMakeVisible(component);
    }
}

void EQGUI::enableDisableGUI()
{
    // Enable/disable stuff according to the toggle buttons 
    auto safePtr = juce::Component::SafePointer<EQGUI>(this);

    // Enable/disable lowcut sliders
    lowcutBypassedButton.onClick = [safePtr]()
    {
        if (auto* component = safePtr.getComponent())
        {
            bool bypassed = component->lowcutBypassedButton.getToggleState();

            component->lowCutFreqSlider.setEnabled(!bypassed);
            component->lowCutSlopeSlider.setEnabled(!bypassed);
        }
    };

    lowCutFreqSlider.setEnabled(!lowcutBypassedButton.getToggleState());
    lowCutSlopeSlider.setEnabled(!lowcutBypassedButton.getToggleState());

    // Enable/disable peak sliders
    peakBypassedButton.onClick = [safePtr]()
    {
        if (auto* component = safePtr.getComponent())
        {
            bool bypassed = component->peakBypassedButton.getToggleState();

            component->peakFreqSlider.setEnabled(!bypassed);
            component->peakGainSlider.setEnabled(!bypassed);
            component->peakQualitySlider.setEnabled(!bypassed);

        }
    };

    peakFreqSlider.setEnabled(!peakBypassedButton.getToggleState());
    peakGainSlider.setEnabled(!peakBypassedButton.getToggleState());
    peakQualitySlider.setEnabled(!peakBypassedButton.getToggleState());

    // Enable/disable highcut sliders
    highcutBypassedButton.onClick = [safePtr]()
    {
        if (auto* component = safePtr.getComponent())
        {
            bool bypassed = component->highcutBypassedButton.getToggleState();

            component->highCutFreqSlider.setEnabled(!bypassed);
            component->highCutSlopeSlider.setEnabled(!bypassed);
        }
    };

    highCutFreqSlider.setEnabled(!highcutBypassedButton.getToggleState());
    highCutSlopeSlider.setEnabled(!highcutBypassedButton.getToggleState());
}

void EQGUI::drawGUI()
{
    auto bounds = getLocalBounds();

    bounds.removeFromTop(10);

    auto lowCutArea = bounds.removeFromLeft(bounds.getWidth() * 0.33);
    auto highCutArea = bounds.removeFromRight(bounds.getWidth() * 0.5);

    lowcutBypassedButton.setBounds(lowCutArea.removeFromTop(25));
    lowCutFreqSlider.setBounds(lowCutArea.removeFromTop(lowCutArea.getHeight() * 0.5));
    lowCutSlopeSlider.setBounds(lowCutArea);

    peakBypassedButton.setBounds(bounds.removeFromTop(25));
    peakFreqSlider.setBounds(bounds.removeFromTop(bounds.getHeight() * 0.33));
    peakGainSlider.setBounds(bounds.removeFromTop(bounds.getHeight() * 0.5));
    peakQualitySlider.setBounds(bounds);

    highcutBypassedButton.setBounds(highCutArea.removeFromTop(25));
    highCutFreqSlider.setBounds(highCutArea.removeFromTop(highCutArea.getHeight() * 0.5));
    highCutSlopeSlider.setBounds(highCutArea);
}
